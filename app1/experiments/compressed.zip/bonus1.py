text = str(input("Enter a title: "))
print(len(text))
