password = input("Enter your password: ")
while password != "pass123":
    password = input("Enter your password: ")

print("Password accepted")